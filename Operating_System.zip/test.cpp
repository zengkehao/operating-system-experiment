#include <cstring>
#include <stdlib.h>
#include<iostream>
using namespace std;

typedef struct Node{
    int PID;     //������
    int runTime;    //����ʱ��
    int priority;   //����Ȩ
    int state;   //״̬
    Node* next;      //ָ��
}Node,*PCB;

void InitPCB (PCB *plink)
{
    (*plink) = (PCB)malloc(sizeof(Node));
    (*plink)->PID = 1;
    (*plink)->runTime = 0;
    (*plink)->priority = 0;
    (*plink)->state = 1;
    (*plink)->next = NULL;
}

//void CreateLinked(PCB plink)
//{
//    PCB p;
//    PCB head = plink;
//}

void AddPCB(PCB plink,int PID, int runTime, int priority,int state)
{
//    PCB p;
//    PCB head;
//	head = plink->next; 
//    
//    p = (PCB)malloc(sizeof(Node));
//    
//    p->PID = PID;
//    p->runTime = runTime;
//    p->priority = priority;
//    p->state = state;
//    p->next = NULL;
//    
//    while(head != NULL)
//    {
//    	head = head->next;
//	}
//	
//	head->next = p;
	
	PCB p;
    PCB head;
    head = plink;
    bool flag = true;

    p = (PCB)malloc(sizeof(Node));

    p->PID = PID;
    p->runTime = runTime;
    p->priority = priority;
    p->state = state;
    p->next = NULL;

    while(head->next != NULL)
    {
        head = head->next;
        if(head->PID == PID)
        {
            flag = false;
            break;
        }
    }
    
    head->next = p;
}

void PrintPCB(PCB plink)
{
    cout << "PCB:" << endl;
    PCB p = plink->next;
    while(p != NULL)
    {
        cout << "P"<<p->PID << " ";
        cout << p->runTime << " ";
        cout << p->priority << " ";
        cout << p->state << " ";

        p = p->next;
        cout << endl;
    }
}

void Swap(PCB p1,PCB p2)
{
	PCB p;
	p->PID = p1->PID;
	p->runTime = p1->runTime;
	p->priority = p1->priority;
	p->state = p1->state;
	
	p1->PID = p2->PID;
	p1->runTime = p2->runTime;
	p1->priority = p2->priority;
	p1->state = p2->state;
	
	p2->PID = p->PID;
	p2->runTime = p->runTime;
	p2->priority = p->priority;
	p2->state = p->state;	
}


void SortPCB(PCB plink)
{
	PCB pIndex = plink;
	PCB p,pMin,pTemp;
	InitPCB(&pTemp); 
	int n = 0;
	while(pIndex->next != NULL)
	{
		pIndex = pIndex->next;
		p = pIndex;
		pMin = pIndex;
		while(p->next != NULL)
		{
			p = p->next;
			if(p->priority < pMin->priority)
			{
				pMin = p;
			}
		}
		
		cout << "pIndex->PID:" << pIndex->PID << endl;
		cout << "pMin->PID:" << pMin->PID << endl;
		
		pTemp->PID = pIndex->PID;
		pTemp->runTime = pIndex->runTime;
		pTemp->priority = pIndex->priority;
		pTemp->state = pIndex->state;
		pTemp->next = pIndex->next; 
	
		pIndex->PID = pMin->PID;
		pIndex->runTime = pMin->runTime;
		pIndex->priority = pMin->priority;
		pIndex->state = pMin->state;
		pIndex->next = pMin->next;
	
		pMin->PID = pTemp->PID;
		pMin->runTime = pTemp->runTime;
		pMin->priority = pTemp->priority;
		pMin->state = pTemp->state;
		pMin->next = pTemp->next;
	
		
		cout << "n:" << endl;
		n++;	
	}
	
	cout << n << endl;
}


int main()
{
    PCB plink1,plink2;
    
    //InitPCB(&plink1);
    plink1 = (PCB)malloc(sizeof(Node));
    plink2 = (PCB)malloc(sizeof(Node));
    
    AddPCB(plink1, 1,4,3,1);
    AddPCB(plink1, 2,3,1,1);
    AddPCB(plink1, 3,2,2,1);
    SortPCB(plink1);
    PrintPCB(plink1);
    
//    PCB p,head,p1;
//    p = plink1->next;
//    head = p;
//    p = p->next;
//    
//    head->next = p->next;
//    delete p;
//    PrintPCB(plink1);

    return 0;
}
