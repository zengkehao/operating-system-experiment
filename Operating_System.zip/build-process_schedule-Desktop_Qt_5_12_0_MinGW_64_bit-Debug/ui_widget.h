/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QFrame *Add;
    QPushButton *AddButton;
    QPushButton *ClearButton;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *plus_process;
    QLineEdit *PID;
    QLineEdit *RunTime;
    QSpinBox *priority;
    QLabel *label_22;
    QLineEdit *memsize;
    QFrame *Reserve;
    QLabel *PoolQueue;
    QPushButton *JobpushButton;
    QPlainTextEdit *PoolplainTextEdit;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_10;
    QPushButton *SortpushButton;
    QFrame *Ready;
    QLabel *ReadyQueue;
    QPlainTextEdit *ReadyplainTextEdit;
    QPushButton *CPUpushButton;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_11;
    QLabel *label_12;
    QPushButton *SortReadypushButton;
    QFrame *frame;
    QLabel *Suspendedlabel;
    QPlainTextEdit *SuspendedplainTextEdit;
    QPushButton *SuspendedpushButton;
    QPushButton *LosspushButton;
    QLabel *label_13;
    QLabel *label_14;
    QLineEdit *SuspendedlineEdit;
    QLineEdit *LosslineEdit;
    QLabel *label_15;
    QFrame *frame_2;
    QLabel *CPUlabel;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QSpinBox *NumOfTrack;
    QLabel *label_19;
    QLineEdit *PIDlineEdit;
    QLineEdit *RunTimelineEdit;
    QLineEdit *PrioritylineEdit;
    QLabel *label_20;
    QSpinBox *CPUSchedulingMethod;
    QLabel *label_21;
    QSpinBox *TimeSlice;
    QPushButton *pushButton_2;
    QTableView *MemoryTableView;
    QTableView *PartitionTableView;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(959, 665);
        Add = new QFrame(Widget);
        Add->setObjectName(QString::fromUtf8("Add"));
        Add->setGeometry(QRect(10, 21, 311, 231));
        Add->setFrameShape(QFrame::StyledPanel);
        Add->setFrameShadow(QFrame::Raised);
        AddButton = new QPushButton(Add);
        AddButton->setObjectName(QString::fromUtf8("AddButton"));
        AddButton->setGeometry(QRect(10, 160, 92, 28));
        ClearButton = new QPushButton(Add);
        ClearButton->setObjectName(QString::fromUtf8("ClearButton"));
        ClearButton->setGeometry(QRect(160, 160, 92, 28));
        label = new QLabel(Add);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 70, 72, 20));
        label_3 = new QLabel(Add);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(250, 70, 72, 15));
        label_2 = new QLabel(Add);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(90, 70, 91, 16));
        plus_process = new QLabel(Add);
        plus_process->setObjectName(QString::fromUtf8("plus_process"));
        plus_process->setGeometry(QRect(10, 10, 111, 41));
        QFont font;
        font.setPointSize(14);
        plus_process->setFont(font);
        PID = new QLineEdit(Add);
        PID->setObjectName(QString::fromUtf8("PID"));
        PID->setGeometry(QRect(10, 100, 61, 21));
        RunTime = new QLineEdit(Add);
        RunTime->setObjectName(QString::fromUtf8("RunTime"));
        RunTime->setGeometry(QRect(90, 100, 71, 21));
        priority = new QSpinBox(Add);
        priority->setObjectName(QString::fromUtf8("priority"));
        priority->setGeometry(QRect(250, 100, 46, 22));
        priority->setMinimum(1);
        priority->setMaximum(7);
        label_22 = new QLabel(Add);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(170, 70, 72, 15));
        memsize = new QLineEdit(Add);
        memsize->setObjectName(QString::fromUtf8("memsize"));
        memsize->setGeometry(QRect(170, 100, 51, 21));
        Reserve = new QFrame(Widget);
        Reserve->setObjectName(QString::fromUtf8("Reserve"));
        Reserve->setGeometry(QRect(320, 20, 291, 231));
        Reserve->setFrameShape(QFrame::StyledPanel);
        Reserve->setFrameShadow(QFrame::Raised);
        PoolQueue = new QLabel(Reserve);
        PoolQueue->setObjectName(QString::fromUtf8("PoolQueue"));
        PoolQueue->setGeometry(QRect(10, 20, 91, 31));
        PoolQueue->setFont(font);
        JobpushButton = new QPushButton(Reserve);
        JobpushButton->setObjectName(QString::fromUtf8("JobpushButton"));
        JobpushButton->setGeometry(QRect(120, 20, 81, 28));
        PoolplainTextEdit = new QPlainTextEdit(Reserve);
        PoolplainTextEdit->setObjectName(QString::fromUtf8("PoolplainTextEdit"));
        PoolplainTextEdit->setGeometry(QRect(20, 100, 231, 111));
        layoutWidget = new QWidget(Reserve);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 70, 261, 17));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_2->addWidget(label_4);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_2->addWidget(label_5);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_2->addWidget(label_6);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_2->addWidget(label_10);

        SortpushButton = new QPushButton(Reserve);
        SortpushButton->setObjectName(QString::fromUtf8("SortpushButton"));
        SortpushButton->setGeometry(QRect(210, 20, 41, 28));
        Ready = new QFrame(Widget);
        Ready->setObjectName(QString::fromUtf8("Ready"));
        Ready->setGeometry(QRect(10, 260, 301, 221));
        Ready->setFrameShape(QFrame::StyledPanel);
        Ready->setFrameShadow(QFrame::Raised);
        ReadyQueue = new QLabel(Ready);
        ReadyQueue->setObjectName(QString::fromUtf8("ReadyQueue"));
        ReadyQueue->setGeometry(QRect(10, 10, 101, 41));
        ReadyQueue->setFont(font);
        ReadyplainTextEdit = new QPlainTextEdit(Ready);
        ReadyplainTextEdit->setObjectName(QString::fromUtf8("ReadyplainTextEdit"));
        ReadyplainTextEdit->setGeometry(QRect(10, 90, 261, 131));
        CPUpushButton = new QPushButton(Ready);
        CPUpushButton->setObjectName(QString::fromUtf8("CPUpushButton"));
        CPUpushButton->setGeometry(QRect(120, 20, 71, 28));
        layoutWidget1 = new QWidget(Ready);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 60, 281, 17));
        horizontalLayout = new QHBoxLayout(layoutWidget1);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout->addWidget(label_7);

        label_8 = new QLabel(layoutWidget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout->addWidget(label_8);

        label_9 = new QLabel(layoutWidget1);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout->addWidget(label_9);

        label_11 = new QLabel(layoutWidget1);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        horizontalLayout->addWidget(label_11);

        label_12 = new QLabel(layoutWidget1);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        horizontalLayout->addWidget(label_12);

        SortReadypushButton = new QPushButton(Ready);
        SortReadypushButton->setObjectName(QString::fromUtf8("SortReadypushButton"));
        SortReadypushButton->setGeometry(QRect(220, 20, 41, 28));
        frame = new QFrame(Widget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(10, 490, 591, 161));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        Suspendedlabel = new QLabel(frame);
        Suspendedlabel->setObjectName(QString::fromUtf8("Suspendedlabel"));
        Suspendedlabel->setGeometry(QRect(10, 0, 91, 31));
        Suspendedlabel->setFont(font);
        SuspendedplainTextEdit = new QPlainTextEdit(frame);
        SuspendedplainTextEdit->setObjectName(QString::fromUtf8("SuspendedplainTextEdit"));
        SuspendedplainTextEdit->setGeometry(QRect(10, 40, 261, 121));
        SuspendedpushButton = new QPushButton(frame);
        SuspendedpushButton->setObjectName(QString::fromUtf8("SuspendedpushButton"));
        SuspendedpushButton->setGeometry(QRect(510, 50, 51, 28));
        LosspushButton = new QPushButton(frame);
        LosspushButton->setObjectName(QString::fromUtf8("LosspushButton"));
        LosspushButton->setGeometry(QRect(510, 120, 51, 28));
        label_13 = new QLabel(frame);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(330, 60, 51, 16));
        label_14 = new QLabel(frame);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(330, 120, 41, 16));
        SuspendedlineEdit = new QLineEdit(frame);
        SuspendedlineEdit->setObjectName(QString::fromUtf8("SuspendedlineEdit"));
        SuspendedlineEdit->setGeometry(QRect(380, 60, 113, 21));
        LosslineEdit = new QLineEdit(frame);
        LosslineEdit->setObjectName(QString::fromUtf8("LosslineEdit"));
        LosslineEdit->setGeometry(QRect(380, 120, 113, 21));
        label_15 = new QLabel(frame);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(340, 10, 201, 16));
        frame_2 = new QFrame(Widget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(320, 260, 281, 221));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        CPUlabel = new QLabel(frame_2);
        CPUlabel->setObjectName(QString::fromUtf8("CPUlabel"));
        CPUlabel->setGeometry(QRect(20, 10, 41, 31));
        QFont font1;
        font1.setPointSize(15);
        CPUlabel->setFont(font1);
        label_16 = new QLabel(frame_2);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(20, 60, 51, 16));
        label_17 = new QLabel(frame_2);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(100, 60, 72, 15));
        label_18 = new QLabel(frame_2);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(190, 60, 72, 15));
        NumOfTrack = new QSpinBox(frame_2);
        NumOfTrack->setObjectName(QString::fromUtf8("NumOfTrack"));
        NumOfTrack->setGeometry(QRect(20, 180, 46, 22));
        NumOfTrack->setMinimum(1);
        NumOfTrack->setMaximum(6);
        NumOfTrack->setSingleStep(1);
        NumOfTrack->setValue(6);
        label_19 = new QLabel(frame_2);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(20, 150, 41, 16));
        PIDlineEdit = new QLineEdit(frame_2);
        PIDlineEdit->setObjectName(QString::fromUtf8("PIDlineEdit"));
        PIDlineEdit->setGeometry(QRect(20, 100, 51, 21));
        RunTimelineEdit = new QLineEdit(frame_2);
        RunTimelineEdit->setObjectName(QString::fromUtf8("RunTimelineEdit"));
        RunTimelineEdit->setGeometry(QRect(100, 100, 71, 21));
        PrioritylineEdit = new QLineEdit(frame_2);
        PrioritylineEdit->setObjectName(QString::fromUtf8("PrioritylineEdit"));
        PrioritylineEdit->setGeometry(QRect(190, 100, 51, 21));
        label_20 = new QLabel(frame_2);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(90, 150, 101, 16));
        CPUSchedulingMethod = new QSpinBox(frame_2);
        CPUSchedulingMethod->setObjectName(QString::fromUtf8("CPUSchedulingMethod"));
        CPUSchedulingMethod->setGeometry(QRect(100, 180, 46, 22));
        CPUSchedulingMethod->setMinimum(1);
        CPUSchedulingMethod->setMaximum(2);
        label_21 = new QLabel(frame_2);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(200, 150, 61, 16));
        TimeSlice = new QSpinBox(frame_2);
        TimeSlice->setObjectName(QString::fromUtf8("TimeSlice"));
        TimeSlice->setGeometry(QRect(200, 180, 46, 22));
        TimeSlice->setMinimum(1);
        TimeSlice->setMaximum(8);
        TimeSlice->setSingleStep(1);
        TimeSlice->setValue(2);
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 488, 571, 2));
        MemoryTableView = new QTableView(Widget);
        MemoryTableView->setObjectName(QString::fromUtf8("MemoryTableView"));
        MemoryTableView->setGeometry(QRect(630, 260, 291, 391));
        PartitionTableView = new QTableView(Widget);
        PartitionTableView->setObjectName(QString::fromUtf8("PartitionTableView"));
        PartitionTableView->setGeometry(QRect(630, 50, 291, 181));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "CPU Scheduling", nullptr));
        AddButton->setText(QApplication::translate("Widget", "\346\267\273\345\212\240", nullptr));
        ClearButton->setText(QApplication::translate("Widget", "\346\270\205\351\231\244", nullptr));
        label->setText(QApplication::translate("Widget", "\350\277\233\347\250\213\345\220\215", nullptr));
        label_3->setText(QApplication::translate("Widget", "\344\274\230\345\205\210\346\235\203", nullptr));
        label_2->setText(QApplication::translate("Widget", "\350\277\220\350\241\214\346\227\266\351\227\264", nullptr));
        plus_process->setText(QApplication::translate("Widget", "\346\267\273\345\212\240\350\277\233\347\250\213", nullptr));
        label_22->setText(QApplication::translate("Widget", "\345\206\205\345\255\230\345\244\247\345\260\217", nullptr));
        PoolQueue->setText(QApplication::translate("Widget", "\345\220\216\345\244\207\351\230\237\345\210\227", nullptr));
        JobpushButton->setText(QApplication::translate("Widget", "\344\275\234\344\270\232\350\260\203\345\272\246", nullptr));
        label_4->setText(QApplication::translate("Widget", "\350\277\233\347\250\213\345\220\215", nullptr));
        label_5->setText(QApplication::translate("Widget", "\350\277\220\350\241\214\346\227\266\351\227\264", nullptr));
        label_6->setText(QApplication::translate("Widget", "\344\274\230\345\205\210\347\272\247", nullptr));
        label_10->setText(QApplication::translate("Widget", "\347\212\266\346\200\201", nullptr));
        SortpushButton->setText(QApplication::translate("Widget", "\346\216\222\345\272\217", nullptr));
        ReadyQueue->setText(QApplication::translate("Widget", "\345\260\261\347\273\252\351\230\237\345\210\227", nullptr));
        CPUpushButton->setText(QApplication::translate("Widget", "CPU\350\260\203\345\272\246", nullptr));
        label_7->setText(QApplication::translate("Widget", "\350\277\233\347\250\213\345\220\215", nullptr));
        label_8->setText(QApplication::translate("Widget", "\350\277\220\350\241\214\346\227\266\351\227\264", nullptr));
        label_9->setText(QApplication::translate("Widget", "\344\274\230\345\205\210\346\235\203", nullptr));
        label_11->setText(QApplication::translate("Widget", "\347\212\266\346\200\201", nullptr));
        label_12->setText(QApplication::translate("Widget", "\346\214\207\351\222\210", nullptr));
        SortReadypushButton->setText(QApplication::translate("Widget", "\346\216\222\345\272\217", nullptr));
        Suspendedlabel->setText(QApplication::translate("Widget", "\346\214\202\350\265\267\351\230\237\345\210\227", nullptr));
        SuspendedpushButton->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", nullptr));
        LosspushButton->setText(QApplication::translate("Widget", "\347\241\256\345\256\232", nullptr));
        label_13->setText(QApplication::translate("Widget", "\346\214\202\350\265\267\357\274\232", nullptr));
        label_14->setText(QApplication::translate("Widget", "\350\247\243\346\214\202\357\274\232", nullptr));
        label_15->setText(QApplication::translate("Widget", "\350\257\267\350\276\223\345\205\245\351\234\200\350\246\201\346\223\215\344\275\234\347\232\204\350\277\233\347\250\213\347\232\204PID", nullptr));
        CPUlabel->setText(QApplication::translate("Widget", "CPU", nullptr));
        label_16->setText(QApplication::translate("Widget", "\350\277\233\347\250\213\345\220\215", nullptr));
        label_17->setText(QApplication::translate("Widget", "\350\277\220\350\241\214\346\227\266\351\227\264", nullptr));
        label_18->setText(QApplication::translate("Widget", "\344\274\230\345\205\210\347\272\247", nullptr));
        label_19->setText(QApplication::translate("Widget", "\351\201\223\346\225\260\357\274\232", nullptr));
        label_20->setText(QApplication::translate("Widget", "CPU\350\260\203\345\272\246\346\226\271\346\263\225\357\274\232", nullptr));
        label_21->setText(QApplication::translate("Widget", "\346\227\266\351\227\264\347\211\207\357\274\232", nullptr));
        pushButton_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
