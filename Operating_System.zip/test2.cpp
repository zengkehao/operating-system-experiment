#include<iostream>
#include<cstring>
#include<string> 
#include<sstream>
using namespace std;


int getNum(string s)
{
	int n;
	for(int i = 1; i <= s.length() - 1; i++)
	{
		n = n * 10;
		n = n + s.at(i) - 48;
	}
	return n;
}

string toString(int n)
{
        stringstream s;
        s << n;
        return s.str();
}

int main()
{
//	string s;
//	cin >> s;
	
	string s = "p56";
	
//	int length;
//	//cout << s.length();
//	
//	int n = 0;
//	
//	for(int i = 1; i <= s.length() - 1; i++)
//	{
//		n = n * 10;
//		n = n + s.at(i) - 48;
//	}
//	
	//n = n + s.at(1) - 48;
	
	//cout << getNum(s);
	//int n = getNum(s);
	int n = 234;
	
	string s2 = toString(n);
	string s1 = "p";
	
	//cout << s2;
	cout << s1 + s2;;
	
	
	return 0;
 } 
